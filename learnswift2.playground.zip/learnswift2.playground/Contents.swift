import UIKit

var str = "Hello Playground"

print("Welcome to Swift")

var x = 10

for index in 1...20{
    let y = index * x
    x-=1
    print(y)
}
